Changelog for rainbow_logging_handler
=====================================

2.2.2 (2014-08-07)
------------------

- bugfix. 2.1.1 could not be installed...


2.2.1 (2014-07-29)
------------------

- Bugfix on encoding specification
- Fix spelling mistake. Thanks to `dueyfinster <https://github.com/dueyfinster>`_ .


2.2.0 (2014-01-13)
------------------

- Adds custom time format support


2.1.2 (2013-12-27)
------------------

- Adds version badge on README


2.1.1 (2013-12-20)
------------------

- Updats Django example to match the RainbowLoggingHandler new initializer


2.1.0 (2013-12-06)
------------------

- Adds usage w/ Django

2.0.2 (2013-12-05)
------------------

- Updates docstring of `RainbowLoggingHandler.__init__()`

2.0.1 (2013-12-05)
------------------

- Bugfix for Python 3.2

2.0.0 (2013-12-05)
------------------

- Adds custom color & format feature

1.0.4 (2013-12-03)
------------------

- Updates `classifiers` on `setup.py`


1.0.3 (2013-12-03)
------------------

- Fix on README


1.0.2 (2013-12-03)
------------------

- Fix on license


1.0.1 (2013-12-03)
------------------

- Fix on packaging


1.0.0 (2013-12-03)
------------------

- First release
