from photons_app.errors import PhotonsAppError


class InteractorError(PhotonsAppError):
    pass
