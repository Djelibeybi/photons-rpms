Photons Interactor
==================

A `Photons <https://photons.delfick.com>`_ powered server for
interacting with LIFX lights over the lan.

The server allows us to do continuous discovery and information gathering so that
all commands are super fast.

You can find documentation at
https://photons.delfick.com/apps/interactor/index.html
