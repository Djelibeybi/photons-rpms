.. _aiohttp_changes:

.. include:: ../CHANGES.rst

.. include:: ../HISTORY.rst
