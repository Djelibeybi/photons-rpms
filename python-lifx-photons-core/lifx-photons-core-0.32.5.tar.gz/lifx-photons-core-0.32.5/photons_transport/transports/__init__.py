"""
A transport is an object representing a single connection to a device.
"""
