"""
A session object holds the discovery information per device and knows how to
to talk to the device.
"""
