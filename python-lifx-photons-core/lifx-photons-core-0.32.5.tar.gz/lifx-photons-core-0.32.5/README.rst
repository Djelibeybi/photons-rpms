Photons
=======

Photons is Python3.6+ framework for interacting with LIFX products.

See full documentation at https://photons.delfick.com

Example scripts can be found in the ``examples`` folder in this repository.
