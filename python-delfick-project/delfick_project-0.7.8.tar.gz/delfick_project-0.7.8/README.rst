Project helpers
===============

This is a collection of code that I use in nearly all my projects:

* Mainline helper
* Custom python exception class
* Logging helpers
* Option merging
* Validation and Normalisation of data
* Module addon system

Documentation can be found at https://delfick-project.readthedocs.io/en/latest/
