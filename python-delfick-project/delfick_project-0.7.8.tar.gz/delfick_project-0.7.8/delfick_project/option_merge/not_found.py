class NotFound(Exception):
    """Used to signify no value was found"""
