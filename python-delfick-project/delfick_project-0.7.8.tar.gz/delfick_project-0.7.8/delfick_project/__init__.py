"""pytest-cov: avoid already-imported warning: PYTEST_DONT_REWRITE."""
VERSION = "0.7.8"
